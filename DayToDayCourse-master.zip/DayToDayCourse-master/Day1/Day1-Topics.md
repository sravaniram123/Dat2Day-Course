
# 08th Aug 2018 - Today's topics:

#### 1. First 4 weeks plan.

Phase-1: https://docs.google.com/spreadsheets/d/1qN9TlmYgFrIB0KIMV4PoS4_C6O4gtk5-kUnIDDlBPq8/edit?usp=sharing

#### 2. Maven Intro.

#### 3. Maven installation on Windows.
  
        3.1. Refer the document: Java_Maven_Setup.docx
  
#### 4. Create a Linux machine on AWS.

        4.1. Refer Phase-1 docs.

#### 5. Maven installation on Linux machine.

        5.1. Refer Phase-1 docs.


![build-and-deploy](https://user-images.githubusercontent.com/24622526/40571519-be89b376-6089-11e8-9404-5ce00c9df5a1.jpg)

